# CoffeeShopManager
## Mô tả
Ứng dụng quản lý shop cafe bao gồm giao diện cho quản lý và giao diện cho nhân viên trên nền tảng Windows.  
* Phần giao diện cho quản lý sẽ gồm: quản lý các nhân viên trong shop, quản lý thông tin khách hàng, quản lý các thức uống trong menu, quản lý doanh thu, chi phí,...  
* Giao diện cho nhân viên gồm: quản lý các hóa đơn, số lượng bàn trong shop,...  
## Các thành viên nhóm
* [Đỗ Phi Long](https://github.com/Longsans) - 19521777
* [Nguyễn Cao Cường](https://github.com/feelings93) - 19521298  
* [Đinh Việt Hào](https://github.com/HaoDinh9999) - 19521475
## Giảng viên hướng dẫn
* Nguyễn Tấn Toàn